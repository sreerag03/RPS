<?php
$lang = $_GET['lang'];
include("lang/main.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>LocalServer v.<? echo ""._VAPP.""; ?></title>
<link rel="stylesheet" href="css/style.css" />
<link rel="icon" href="images/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
</head>
<body>
<div class="page">
  <div class="lang"><? echo ""._LANG."" ?> : <a href="index?lang=<? if ($_REQUEST[lang] == "en"){echo _LID;} elseif ($_REQUEST[lang] == "id") {echo _LEN;} else {echo _LID;} ?>" title="<? echo ""._TCHANGE.""; ?>"><img src="images/<? if ($_REQUEST[lang] == "en"){echo _LID;} elseif ($_REQUEST[lang] == "id") {echo _LEN;} else {echo _LID;} ?>.png" /></a></div>
<h2>Wellcome to LocalServer v.<? echo ""._VAPP.""; ?></h2>
<a class="menu" href="../phpMyAdmin" target="_blank" title="phpMyAdmin">phpMyAdmin <? echo ""._VPHPMYADMIN.""; ?></a> | <a class="menu" href="../phpinfo" target="_blank" title="phpinfo">PHP <? echo ""._VPHP."" ?></a>
<p><? echo ""._INFO.""; ?> <? echo ""._TRELEASE.""; ?></p>
<div align="center">
<table width="462">
<tr>
  <td width='104' style='float:left;'>+ Apache v.<? echo ""._VAPACHE.""; ?></td>
  <td width='0' style='float:left;'></td>
<td width='342'><? echo ""._SERNAM.""; ?>: LocalServer<br />
  <? echo ""._SERPORT.""; ?>: localhost:4008
  <br />
  ------------------------------</td>
</tr>
<tr>
  <td width='104' style='float:left;'>+ php v.<? echo ""._VPHP.""; ?></td>
  <td width='0' style='float:left;'></td>
<td width='342'><? echo ""._PHPOPEN.""; ?><br />
  ------------------------------</td>
</tr>
<tr><td colspan='3'></tr>
<tr>
  <td style='float:left;'>+ MySQL v.<? echo ""._VMYSQL.""; ?></td>
  <td style='float:left;'></td>
  <td><? echo ""._SERNAM.""; ?>: LocalMySQL<br />
    <? echo ""._SERPORT.""; ?>: localhost:3308<br />
    =&gt; <font color='#FF0000'>Username : root, Password : 1234</font>
<br />
------------------------------</td>
</tr>
<tr><td colspan='3'></tr>
<tr>
  <td style='float:left;'>+ Mercury v.<? echo ""._VMERCURY.""; ?></td>
  <td style='float:left;'></td><td><? echo ""._EMAILSERVER.""; ?><br />
  =&gt; <font color='#FF0000'><? echo ""._USEOUTLOOK.""; ?></font><br>
  =&gt; <font color='#FF0000'>Username : mail@localhost, Password : 1234</font>
<br />
------------------------------</td>
</tr>
<tr><td colspan='3'></tr>
<tr><td style='float:left;'>+ Sendmail v.<? echo ""._VSENDMAIL.""; ?></td><td style='float:left;'></td>
<td><? echo ""._SMTPSERVER.""; ?><br />=&gt; <font color='#FF0000'><? echo ""._USEGMAIL.""; ?></font>
<br />
------------------------------</td>
</tr>
<tr><td colspan='3'></tr>
<tr><td style='float:left;'>+ Test Mail v.<? echo ""._VTESTMAIL.""; ?></td><td style='float:left;'></td>
<td><? echo ""._FORSENDMAIL.""; ?>
<br />
------------------------------</td>
</tr>
<tr><td colspan='3'></tr>
<tr><td style='float:left;'>+ phpMyAdmin v.<? echo ""._VPHPMYADMIN.""; ?></td><td style='float:left;'></td>
<td><? echo ""._FORMANAGEDATA.""; ?>
<br />
------------------------------</td>
</tr>
<tr><td colspan='3'></tr>
</table>
</div>
</div>
<div class="copy">
&copy; 2012 - <a target='_blank' href='http://www.tutorialwebgratis.com' title='PHP Tutorial'>tutorialwebgratis.com</a>
</div>
</body>
</html>