<?php
if (isset( $_GET['s']))
{ require_once( dirname(_FILE_) . '/classes/class-search.php');
    $search= new search();
    $search_term= $_GET['s'];
    $search_results= $search->search($search_term);
}
?>    
<html>
<head>
<title>RPS-Answer Engine

</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
<meta name="msapplication-config" content="/browserconfig.xml?_v=1470063461">
<link rel="shortcut icon" href="http://revolution-systems.com/wp-content/uploads/rpslogonotext.png">
<link rel="stylesheet" type="text/css" href="mystyles.css"/>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript"></script>
</style>

</head>
<body>
<ul>
  <li> <a class="active" href="hi.html"> Home</a></li>
  <li><a href="RPS_BIO.html">About</a></li>
  <li><a href="signIn.html">Register</a></li>
  
</ul>

<h1> <b> RPS</b> </h1> <h3> Queries Have A Better Destination </h3>


<form method='get' action="">
    <input type="search" name="s" id="search_box" placeholder= "search" results="5" value=<?php echo $search_term; ?>/>
    <input type="submit" value="Search" /><br />
</form>
<?php if ($search_results) : ?>
    <p><?php echo $search_results['count']; ?> results found </p>
<?php foreach ($searchresults['results'] as $search_results) : ?>
    <p><?php echo $search_result->title; ?></p>
<?php endforeach; ?>
<pre><?php print_r($earch_results); ?></pre>
<?php endif; ?>

</body>
</html>