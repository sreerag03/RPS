<? php
class sum
{
	 var $z;
	function getdata($x,$y)
	{
		$this-> z = $x + $y;
		echo $this->z;
	}
}
class avg extends sum{
	function setdata(){
global $z
		$av =$z/2;
		echo $av;
	}
}
$b= new avg();
$b->getdata(10,5);
$b->setdata();
?>