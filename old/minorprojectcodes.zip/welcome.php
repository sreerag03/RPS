<?php
echo "welcome";
$x = " Hello";
$y = "PHP";
$z = $x . $y;
echo $z . " haha";
$a=10;

echo var_dump($z);

echo var_dump($a);



?>